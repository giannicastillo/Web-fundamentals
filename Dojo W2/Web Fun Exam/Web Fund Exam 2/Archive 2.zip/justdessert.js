function hide (element){
    element.remove();
    
    console.log()
}
function alertMe(){
    alert('You are searching for tiramisu')
}

function add1(){
    likebtn1++;
    likebtn1Element.innerText = likebtn1 + "likebtn1"
    console.log(likebtn1)
}
function add2(){
    likebtn2++;
    likebtn2Element.innerText = likebtn2 + "likebtn2"
    console.log(likebtn2)
}